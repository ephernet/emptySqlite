<?php
/* ------------------------------ EMPTY SQLITE ------------------------
 *
 * Place this file and any SQLite Database file in the same directory.
 * Database files will be listed for you to select.
 * Upon file selection, all tables will be listed followed by . . . 
 * The [Empty Tables] Button and the [Cancel] Button.
 * NOTE; ALWAYS BE SURE TO BACK UP YOUR DATA.
 */
define('abs_path', dirname(__FILE__));
$dbs = glob('*.{db,sqlite,sqlite3}', GLOB_BRACE);
$db = (isset($_REQUEST["db"]) ? $_REQUEST["db"] : null);
if(isset($_POST["cancel"])){
$db = null;
}
define('db',$db);
//------------------------------------------------------------XXX
class phpSQLite extends SQLite3
{
function __construct()
    {
        $this->open(db);
    }
    function db_close()
    {
        $this->close();
    }
    function db_query($sql)
    {
        $result = $this->query($sql);
		return $result;
    }
    function db_delete($sql)
    {
        $this->query($sql);
    }
}
?>
<!doctype html>
<html>
<head>
<style>
 body,html{font-family:arial;}
.container{width:80%; border:1px solid #000; margin: 0 auto;}
.path{width:98%; border:1px solid #000; margin:0; background:#000; font-weight:bold; color:#fff;padding:10px;}
.db{width:98%; border:1px solid #000; margin:0; background:#ff0; font-weight:bold; color:#000; padding:10px;}
.db a{text-decoration:none;}
.tables{width:98%; border:1px solid #000; margin:0; background:#fff; font-weight:bold; color:#000; padding:5px;}
.dbpath{width:98%; border:1px solid #000; margin:0; background:#f00; font-weight:bold; color:#fff;padding:10px;}
.empty{width:98%; border:0 solid #000; margin:0; background:#fff; font-weight:normal; color:#f00;padding:1px;}
 form{padding:10px;background:#ccc;}
 button{margin:10px;}
</style>
<meta charset="utf-8">
<title>Empty SQLite</title>
</head>
<body>
<div class="container">
<?php
echo '<div class="path">Path = ' .abs_path.'</div>';
if($db == null){
//----------------------------------------------------------[LIST SQLITE FILES]	
foreach($dbs as $dbf)
{
  echo "<div class='db'><a href='?db=".$dbf."'>".$dbf."</a></div>";
}
}else{
//----------------------------------------------------------[LIST SQLITE TABLES]
$sqlite = new phpSQLite();
$sql =  "SELECT name FROM sqlite_master WHERE type='table' and not name = 'sqlite_stat1';";
$res = $sqlite->db_query($sql);
if($res){
echo '<div class="dbpath">'.db.'</div>';
while ($row = $res->fetchArray()) {
echo '<div class="tables">'.$row[0].'</div>';
}
}else{
echo '<div class="tables">No Tables Found</div>';
}
$sqlite->db_close();
$res = null;
unset($sqlite);
echo "\n<form method='post' action='index.php?db=".$db."'>\n";
echo "<button name='empty' type='submit'>empty tables</button>";
echo "<button name='cancel' type='submit'>cancel</button>\n";
echo "</form>\n";
//---------------------------------------------------------------[empty data]
if(isset($_POST["empty"])){
$sqlite = new phpSQLite();
$sql =  "SELECT name FROM sqlite_master WHERE type='table' and not name = 'sqlite_stat1';";
$res = $sqlite->db_query($sql);
if($res){
while ($row = $res->fetchArray()) {
$sql = "delete from ".$row[0];
$sqlite->db_delete($sql);
echo '<div class="empty">'.$sql.'</div>';
}
}
$sqlite->db_close();
$res = null;
unset($sqlite);
}
}
?>
</div>
</body>
</html>